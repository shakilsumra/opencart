<?php
// Text
$_['text_title'] = 'Octifi Payment';